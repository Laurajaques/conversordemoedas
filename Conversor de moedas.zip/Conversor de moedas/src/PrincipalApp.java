import java.util.Scanner;

public class PrincipalApp {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);

        int opcao = 0;

        while (opcao != 7) {

            System.out.println("Digite uma das opções a seguir");
            System.out.println("********************************");
            System.out.println("1 - Dólar para real");
            System.out.println("2 - Real para dólar");
            System.out.println("3 - Euro para real");
            System.out.println("4 - Real para euro");
            System.out.println("5 - Real para libras");
            System.out.println("6 - Libras para real");
            System.out.println("7 - Sair");

            opcao = teclado.nextInt();

            if (opcao == 7) {
                System.out.println("Encerrando o programa...");
                break;

            }
            System.out.print("Digite o valor: ");
            double valor = teclado.nextDouble();

            try {
                double resultado = 0;

                switch (opcao) {
                    case 1:

                        resultado = ConversorService.converter("USD", "BRL", valor);
                        break;
                    case 2:
                        resultado = ConversorService.converter("BRL", "USD", valor);
                        break;
                    case 3:
                        resultado = ConversorService.converter("EUR", "BRL", valor);
                        break;
                    case 4:
                        resultado = ConversorService.converter("BRL", "EUR", valor);
                        break;
                    case 5:
                        resultado = ConversorService.converter("GBP", "BRL", valor);
                        break;
                    case 6:
                        resultado = ConversorService.converter("BRL", "GBP", valor);
                        break;
                    default:
                        System.out.println("Opção inválida!");
                        continue;
                }

                System.out.println("Resultado da conversão: " + resultado);

            } catch (Exception e) {
                System.out.println("Erro ao acessar a API.");
            }
        }
        teclado.close();
    }
}