
import com.google.gson.Gson;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ConversorService {
    private static final String API_KEY = "474d5c6bcbd8ac8ba6925e32";

    public static double converter(String origem, String destino, double valor) throws Exception {


            String url = "https://v6.exchangerate-api.com/v6/"
                    + API_KEY + "/latest/" + origem;

            HttpClient client = HttpClient.newHttpClient();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .GET()
                    .build();

            HttpResponse<String> response =
                    client.send(request, HttpResponse.BodyHandlers.ofString());

            Gson gson = new Gson();
            ExchangeResponse dados =
                    gson.fromJson(response.body(), ExchangeResponse.class);

            double taxa = dados.conversion_rates.get(destino);
            return valor * taxa;
    }
}
