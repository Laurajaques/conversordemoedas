import java.util.Map;

public class ExchangeResponse {
    Map<String, Double> conversion_rates;
}